//
//  CLXMagniteAdView.h
//  CloudXMagniteAdapter
//

#import <Foundation/Foundation.h>

#import <CloudXCore/CLXAdapterAdView.h>
#import <CloudXCore/CLXAdapterLogger.h>
#import <CloudXCore/CLXBannerType.h>
#import <CloudXCore/CLXAdapterLogger.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Magnite banner adapter implementing CloudX adapter protocol.
 * Manages the lifecycle of Magnite banner/MREC ads including loading and cleanup.
 * Supports standard banner (320x50) and MREC (300x250).
 */
@interface CLXMagniteAdView : CLXAdapterAdView

/**
 * CloudX adapter delegate for receiving ad events.
 * Strong to keep the callback chain alive through the ad lifecycle. Cycle is broken in destroy.
 */
/**
 * The underlying Magnite banner view
 */
/**
 * SDK version of the Magnite SDK
 */
/**
 * Magnite placement ID for this ad
 */
@property (nonatomic, copy, readonly) NSString *placementID;

/**
 * CloudX ad unit name for error messages and logging.
 */
@property (nonatomic, copy, readonly, nullable) NSString *adUnitName;

/**
 * Banner type (size)
 */
@property (nonatomic, assign, readonly) CLXBannerType bannerType;

/**
 * Initializes a new Magnite banner adapter
 * @param bidPayload Ad markup from bid response (nil for waterfall, non-nil for bidding)
 * @param placementID The Magnite placement ID (nullable - validation deferred to load())
 * @param adUnitName The CloudX placement name for error messages (nullable)
 * @param type The banner type/size
 * @return Initialized banner adapter
 */
- (instancetype)initWithBidPayload:(nullable NSString *)bidPayload
                       placementID:(nullable NSString *)placementID
                        adUnitName:(nullable NSString *)adUnitName
                              type:(CLXBannerType)type
                            logger:(id<CLXAdapterLogger>)logger;

/**
 * Destroys the banner ad and cleans up resources
 */
@end

NS_ASSUME_NONNULL_END
