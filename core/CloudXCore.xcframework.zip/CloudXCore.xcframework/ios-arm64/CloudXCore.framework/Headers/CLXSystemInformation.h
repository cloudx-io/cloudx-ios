/*
 * Copyright (c) 2024 CloudX. All rights reserved.
 */

/**
 * @file SystemInformation.h
 * @brief Provides system information functionality for the CloudX SDK
 * @details This class provides access to various system information properties
 *          including device type, SDK version, app version, and identifiers.
 *          The DeviceType enum represents the type of device (phone, tablet, or unknown).
 */

#import <Foundation/Foundation.h>

@class CLXLogger;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, DeviceType) {
    DeviceTypePhone = 4,
    DeviceTypeTablet = 5,
    DeviceTypeUnknown = 1
};

/**
 * @class SystemInformation
 * @brief Singleton class providing system information
 * @discussion This class provides access to various system information needed by the SDK,
 * including device identifiers, OS version, and SDK version.
 */
@interface CLXSystemInformation : NSObject

/** Shared instance of SystemInformation */
@property (class, nonatomic, readonly) CLXSystemInformation *shared;

/** The device type (phone, tablet, or unknown) */
@property (nonatomic, readonly) DeviceType deviceType;

/** The SDK version */
@property (nonatomic, readonly) NSString *sdkVersion;

/** The SDK bundle identifier */
@property (nonatomic, readonly) NSString *sdkBundle;

/** The app bundle identifier (real main bundle) */
@property (nonatomic, readonly) NSString *appBundleIdentifier;

/** The effective app bundle identifier, honoring the emulator bundle override on simulator builds. */
@property (nonatomic, readonly) NSString *effectiveAppBundleIdentifier;

/** The app version */
@property (nonatomic, readonly) NSString *appVersion;

/** The OS version */
@property (nonatomic, readonly) NSString *osVersion;

/** The IDFA (Identifier for Advertisers) */
@property (nonatomic, readonly, nullable) NSString *idfa;

/** The IDFV (Identifier for Vendor) */
@property (nonatomic, readonly, nullable) NSString *idfv;

/** Whether Do Not Track is enabled */
@property (nonatomic, readonly) BOOL dnt;

/** Whether Limit Ad Tracking is enabled */
@property (nonatomic, readonly) BOOL lat;

/** The OS name */
@property (nonatomic, readonly) NSString *os;

/** The device model */
@property (nonatomic, readonly) NSString *model;

/** The system version */
@property (nonatomic, readonly) NSString *systemVersion;

/** The display manager */
@property (nonatomic, readonly) NSString *displayManager;

/**
 * Determines if the app is running from the App Store.
 * Returns NO for debug builds, simulator, TestFlight, and local builds.
 * Returns YES only for production App Store distribution.
 */
@property (nonatomic, readonly) BOOL isAppStoreEnvironment;

@end

NS_ASSUME_NONNULL_END

// Helper function to convert DeviceType enum to NSString
FOUNDATION_EXPORT NSString * _Nonnull DeviceTypeToString(DeviceType type); 