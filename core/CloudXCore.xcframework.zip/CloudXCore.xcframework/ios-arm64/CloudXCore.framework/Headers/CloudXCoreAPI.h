#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CloudXCore/CLXExport.h>
#import <CloudXCore/CLXLogger.h>
#import <CloudXCore/CLXError.h>
#import <CloudXCore/CLXInitializationConfiguration.h>
#import <CloudXCore/CLXSdkConfiguration.h>
#import <CloudXCore/CLXArbiterConfiguration.h>
#import <CloudXCore/CLXArbiterResult.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Notification posted when SDK initialization completes
 * @discussion Internal notification used by ad objects to coordinate queued operations
 */
CLX_PUBLIC
FOUNDATION_EXPORT NSString * const CLXSDKInitializedNotification;

// Forward declarations for public interfaces
@protocol CLXBannerDelegate;
@protocol CLXInterstitialDelegate;
@protocol CLXRewardedDelegate;
@protocol CLXAdRevenueDelegate;
@protocol CLXAppOpenDelegate;
@protocol CLXAdQualityGate;

@class CLXBannerAdView;
@class CLXSDKConfigResponse;
@class CLXSDKConfigAdUnit;
@class CLXInterstitial;
@class CLXRewarded;
@class CLXAppOpen;
@class CLXNativeAdLoader;
@class CLXRevenueData;

typedef void (^CLXArbiterCompletion)(CLXArbiterResult *result);

/**
 * The main class of the CloudX SDK.
 * Use this class to initialise the SDK and create ads.
 * @discussion Thread-safe singleton. All methods should be called from the main thread.
 */
CLX_PUBLIC
@interface CloudXCore : NSObject

/**
 * Use the shared singleton instance instead
 */
- (instancetype)init NS_UNAVAILABLE;

/**
 * Use the shared singleton instance instead
 */
+ (instancetype)new NS_UNAVAILABLE;

/**
 * The shared instance of CloudXCore
 */
@property (class, nonatomic, readonly) CloudXCore *shared;

/**
 * The version of the CloudX SDK
 */
@property (nonatomic, readonly) NSString *sdkVersion;

/**
 * Indicates whether the SDK has completed initialization
 */
@property (nonatomic, readonly) BOOL isInitialized;

/**
 * Initialize the SDK with a configuration object
 * @param configuration The initialization configuration
 * @param completion A completion handler called when initialization completes.
 *                   On success, sdkConfiguration is non-nil and error is nil.
 *                   On failure, sdkConfiguration is nil and error contains failure details.
 * @discussion This is the preferred initialization method. Use CLXInitializationConfiguration
 * to configure the SDK before initialization.
 *
 * Initialization runs at most once at a time. A call made while an earlier call is still
 * initializing does not start another attempt: on success every waiting caller completes with
 * success; on failure the caller that started the attempt receives the error and the next waiting
 * caller drives one fresh attempt, completing with that one's outcome. A call made after a
 * successful initialization completes immediately. A call whose app key is nil or empty fails
 * immediately without starting or joining an attempt.
 *
 * Example:
 * @code
 * CLXInitializationConfiguration *config =
 *     [CLXInitializationConfiguration configurationWithAppKey:@"your-app-key"
 *         builderBlock:^(CLXInitializationConfigurationBuilder *builder) {
 *             builder.pluginVersion = @"flutter-1.2.0";
 *         }];
 * [[CloudXCore shared] initializeWithConfiguration:config completion:^(CLXSdkConfiguration *sdkConfiguration, CLXError *error) {
 *     if (sdkConfiguration) {
 *         NSLog(@"SDK initialized successfully");
 *     } else {
 *         NSLog(@"SDK initialization failed: %@", error.localizedDescription);
 *     }
 * }];
 * @endcode
 */
- (void)initializeWithConfiguration:(CLXInitializationConfiguration *)configuration
                         completion:(nullable void (^)(CLXSdkConfiguration * _Nullable sdkConfiguration, CLXError * _Nullable error))completion
    NS_SWIFT_NAME(initialize(with:completion:));

/**
 * Set the hashed user ID for auction requests
 * @param hashedUserID The hashedUserID provided by CloudX
 */
- (void)setHashedUserID:(NSString *)hashedUserID
    NS_SWIFT_NAME(setHashedUserID(_:));

/**
 * Set a user-level key-value pair for targeting
 * @param key The targeting key
 * @param value The targeting value
 * @discussion User-level key-values are injected into bid requests at server-configured paths.
 * These values are typically user-specific targeting parameters and will be cleared
 * if privacy regulations require removing personal data.
 */
- (void)setUserKeyValue:(NSString *)key value:(NSString *)value;

/**
 * Set an app-level key-value pair for targeting
 * @param key The targeting key
 * @param value The targeting value
 * @discussion App-level key-values are injected into bid requests at server-configured paths.
 * These values are typically app-specific targeting parameters and are not affected
 * by privacy regulations.
 */
- (void)setAppKeyValue:(NSString *)key value:(NSString *)value;

/**
 * Clear all user and app-level key-value pairs
 * @discussion Removes all previously set targeting key-value pairs
 */
- (void)clearAllKeyValues;

/**
 * Create a banner ad
 * @param adUnitId The ad unit ID. This should match the ad unit name in the CloudX dashboard
 * @return A CLXBannerAdView object
 * @discussion Set the delegate property on the returned object to receive ad events.
 */
- (nullable CLXBannerAdView *)createBannerWithAdUnitId:(NSString *)adUnitId
    NS_SWIFT_NAME(createBanner(adUnitId:));

/**
 * @deprecated Use createBannerWithAdUnitId: instead.
 * Create a banner ad with an explicit view controller.
 * @param adUnitId The ad unit ID. This should match the ad unit name in the CloudX dashboard
 * @param viewController The view controller used for modal presentation. No longer required;
 *        the SDK resolves the presenting view controller automatically.
 * @return A CLXBannerAdView object
 */
- (nullable CLXBannerAdView *)createBannerWithAdUnitId:(NSString *)adUnitId
                                        viewController:(UIViewController *)viewController
    NS_SWIFT_NAME(createBanner(adUnitId:viewController:))
    __deprecated_msg("Use createBannerWithAdUnitId: instead. The SDK resolves the presenting view controller automatically.");

/**
 * Create a MREC ad
 * @param adUnitId The ad unit ID. This should match the ad unit name in the CloudX dashboard
 * @return A CLXBannerAdView object
 * @discussion Set the delegate property on the returned object to receive ad events.
 */
- (nullable CLXBannerAdView *)createMRECWithAdUnitId:(NSString *)adUnitId
    NS_SWIFT_NAME(createMREC(adUnitId:));

/**
 * @deprecated Use createMRECWithAdUnitId: instead.
 * Create a MREC ad with an explicit view controller.
 * @param adUnitId The ad unit ID. This should match the ad unit name in the CloudX dashboard
 * @param viewController The view controller used for modal presentation. No longer required;
 *        the SDK resolves the presenting view controller automatically.
 * @return A CLXBannerAdView object
 */
- (nullable CLXBannerAdView *)createMRECWithAdUnitId:(NSString *)adUnitId
                                       viewController:(UIViewController *)viewController
    NS_SWIFT_NAME(createMREC(adUnitId:viewController:))
    __deprecated_msg("Use createMRECWithAdUnitId: instead. The SDK resolves the presenting view controller automatically.");

/**
 * Create an interstitial ad
 * @param adUnitId The ad unit ID. This should match the ad unit name in the CloudX dashboard
 * @return A CLXInterstitial object
 * @discussion Set the delegate property on the returned object to receive ad events
 */
- (nullable CLXInterstitial *)createInterstitialWithAdUnitId:(NSString *)adUnitId
    NS_SWIFT_NAME(createInterstitial(adUnitId:));

/**
 * Create a rewarded ad
 * @param adUnitId The ad unit ID. This should match the ad unit name in the CloudX dashboard
 * @return A CLXRewarded object
 * @discussion Set the delegate property on the returned object to receive ad events
 */
- (nullable CLXRewarded *)createRewardedWithAdUnitId:(NSString *)adUnitId
    NS_SWIFT_NAME(createRewarded(adUnitId:));

/**
 * Create an app open ad
 * @param adUnitId The ad unit ID. This should match the ad unit name in the CloudX dashboard
 * @return A CLXAppOpen object
 * @discussion Set the delegate property on the returned object to receive ad events
 */
- (nullable CLXAppOpen *)createAppOpenWithAdUnitId:(NSString *)adUnitId
    NS_SWIFT_NAME(createAppOpen(adUnitId:));

/**
 * Create a native ad loader
 * @param adUnitIdentifier The ad unit identifier. This should match the ad unit name in the CloudX dashboard
 * @return A CLXNativeAdLoader object
 * @discussion Set the nativeAdDelegate and revenueDelegate on the returned object, then call loadAd.
 */
- (CLXNativeAdLoader *)createNativeAdLoaderWithAdUnitIdentifier:(NSString *)adUnitIdentifier
    NS_SWIFT_NAME(createNativeAdLoader(adUnitIdentifier:));

/**
 * Runs the configured bids through the CloudX arbiter.
 *
 * The SDK submits the configured bids to the Trusted Arbiter and returns the selected
 * platform. If the arbiter service is unavailable or fails, the SDK falls back to the
 * highest plaintext bid supplied to the arbiter.
 */
- (void)arbiterWithConfiguration:(CLXArbiterConfiguration *)configuration
                      completion:(CLXArbiterCompletion)completion
    NS_SWIFT_NAME(arbiter(with:completion:));

/**
 * Reports a publisher-supplied impression revenue event into the ILRD pipeline,
 * emitted as adRevenue telemetry.
 *
 * Publishers forward paid events from any mediation platform via this
 * method. Returns YES if the data was used — either accepted into the ILRD
 * pipeline, or, when adRevenue tracking is not enabled by the server config,
 * recorded as a realized price for later pricing. Returns NO if it was dropped,
 * because the SDK isn't initialized, the platform name is blank, or nothing
 * consumed the event. Acceptance is not a delivery guarantee — reporting itself
 * is fire-and-forget async. Non-throwing and safe to call from a paid-event
 * callback.
 *
 * @param data The impression revenue and metadata to report.
 */
- (BOOL)reportRevenueData:(CLXRevenueData *)data
    NS_SWIFT_NAME(reportRevenueData(_:));

#pragma mark - Visual Debugging

/**
 * Enable or disable the visual debugging overlay
 * @param enabled YES to show the debug overlay, NO to hide it
 * @discussion When enabled, shows a floating debug button that provides:
 * - Click visual feedback (border highlight on ad clicks)
 * - Error display in ad containers (shows load/display errors)
 * - Log viewer (tap the button to see SDK logs)
 * - Error flash (button flashes red when errors occur)
 *
 * This is independent from testMode - you can debug real production ads.
 * The overlay appears immediately when enabled and can be called at any time.
 *
 * Example:
 * @code
 * // Enable visual debugging for live ads
 * [CloudXCore setVisualDebuggingEnabled:YES];
 * @endcode
 */
+ (void)setVisualDebuggingEnabled:(BOOL)enabled;

/**
 * Check if visual debugging is currently enabled
 * @return YES if visual debugging overlay is enabled, NO otherwise
 */
+ (BOOL)isVisualDebuggingEnabled;

#pragma mark - Mediation Debugger

/**
 * @brief Opens the CloudX Mediation Debugger.
 * @discussion An in-app screen listing every installed adapter with its versions and
 * integration status, and the SDK configuration: initialization status, privacy, ad units.
 * Intended for development and QA builds. Requires an initialized SDK: the adapters, server
 * configuration and ad units the screen reports do not exist before initialization. Presented
 * on the current top view controller, which the SDK resolves itself. Callable from any thread;
 * the presentation itself happens on the main thread.
 * @return YES when the SDK is initialized and the screen was requested. NO when the SDK is not
 * initialized, in which case nothing is presented.
 *
 * Example:
 * @code
 * if (![CloudXCore showMediationDebugger]) {
 *     NSLog(@"Initialize the CloudX SDK before opening the Mediation Debugger.");
 * }
 * @endcode
 */
+ (BOOL)showMediationDebugger NS_SWIFT_NAME(showMediationDebugger());

#pragma mark - Logging Control

/**
 * Set minimum log level for SDK logging
 * @param minLogLevel The minimum log level (CLXLogLevelVerbose, CLXLogLevelDebug, CLXLogLevelInfo, CLXLogLevelWarn, CLXLogLevelError, CLXLogLevelNone)
 * @discussion Controls which log messages are displayed. Only logs at or above this level will be shown.
 * Use CLXLogLevelNone to disable all logging. Call this method early in your app lifecycle.
 */
+ (void)setMinLogLevel:(CLXLogLevel)minLogLevel;

/**
 * Enable or disable emojis in logs
 * @param enabled YES to show emojis (default), NO for plain text
 * @discussion Disable emojis when exporting logs to systems that don't support them (Datadog, Splunk, etc)
 */
+ (void)setLoggingEmojisEnabled:(BOOL)enabled;

/**
 * Enable or disable timestamps in logs
 * @param enabled YES to show timestamps, NO to hide (default)
 * @discussion Timestamps are formatted as HH:mm:ss.SSS and appear after [CloudX]. Useful for debugging timing issues.
 */
+ (void)setLoggingTimestampsEnabled:(BOOL)enabled;

#pragma mark - Manual Privacy Controls

/**
 * Set the user's GDPR consent status manually (bypassing CMP frameworks).
 * @param hasUserConsent @YES if user consented, @NO if not, nil to clear (defer to CMP).
 * @discussion Call this @b before initializing the SDK. Some ad network SDKs require privacy
 * settings at initialization time and will not apply values set after init.
 *
 * When set, this value is used as a fallback after GPP/TCF signals in the privacy resolution chain.
 * Setting this also triggers an immediate push of resolved privacy settings to all adapter handlers.
 *
 * Example:
 * @code
 * // Set privacy BEFORE initializing the SDK
 * [CloudXCore setHasUserConsent:@YES];
 * [[CloudXCore shared] initializeWithConfiguration:config completion:completion];
 * @endcode
 */
+ (void)setHasUserConsent:(nullable NSNumber *)hasUserConsent;

/**
 * Set the user's CCPA do-not-sell status manually (bypassing CMP frameworks).
 * @param doNotSell @YES if user opted out of sale, @NO if sale allowed, nil to clear (defer to CMP).
 * @discussion Call this @b before initializing the SDK. Some ad network SDKs require privacy
 * settings at initialization time and will not apply values set after init.
 *
 * When set, this value is used as a fallback after GPP/CCPA signals in the privacy resolution chain.
 * Setting this also triggers an immediate push of resolved privacy settings to all adapter handlers.
 *
 * Example:
 * @code
 * // Set privacy BEFORE initializing the SDK
 * [CloudXCore setDoNotSell:@YES];
 * [[CloudXCore shared] initializeWithConfiguration:config completion:completion];
 * @endcode
 */
+ (void)setDoNotSell:(nullable NSNumber *)doNotSell;

#pragma mark - Ad Revenue Integrations (MMP)

/**
 * Register a global ad-revenue delegate that receives every CloudX-won impression.
 *
 * This is the general, publisher-facing surface (mirrors Android's `CloudX.addAdRevenueListener`):
 * publishers, analytics SDKs, and `CloudX<Mmp>Integration` modules alike can observe revenue without
 * wiring a per-ad `revenueDelegate`. It reuses the same `CLXAdRevenueDelegate` protocol as the per-ad
 * callback. Multiple delegates are supported; registering the same instance twice is a no-op.
 *
 * @param delegate The delegate to register. Ignored if nil.
 * @discussion Thread-safe and safe to call before SDK initialization (e.g. from a module's `+load`).
 * Delivered on the main queue; a delegate that throws is caught and isolated so it cannot break the
 * ad flow or other delegates. Inert until at least one delegate is registered.
 *
 * Not fired for impressions won by a bidder whose own SDK reports revenue to the app's MMPs
 * directly — mediation stacks such as AppLovin MAX and the Google waterfall — since forwarding
 * those would double count. Which bidders those are is server-configured. A per-ad
 * `revenueDelegate` is unaffected and still receives every impression.
 *
 * In a test-mode session the delegate still fires for the same impressions it would in production,
 * with an ad whose `revenue` is @0 and `revenuePrecision` is "undefined", so the integration can be
 * checked on a test device.
 */
+ (void)addAdRevenueDelegate:(id<CLXAdRevenueDelegate>)delegate
    NS_SWIFT_NAME(addAdRevenueDelegate(_:));

/**
 * Remove a delegate previously registered with `addAdRevenueDelegate:` (identity match). No-op if it
 * was never registered. Thread-safe.
 * @param delegate The delegate to remove. Ignored if nil.
 */
+ (void)removeAdRevenueDelegate:(id<CLXAdRevenueDelegate>)delegate
    NS_SWIFT_NAME(removeAdRevenueDelegate(_:));

#pragma mark - Ad Quality Gate

/**
 * Register the ad-quality gate — a single, vendor-neutral participant that
 * inspects every loaded ad before the publisher is told it loaded and may veto
 * ("block") it. A blocked ad is routed into the existing adapter-load-failure
 * path with a @c CLXAdQualityError, so waterfall / refresh / teardown machinery
 * runs unchanged.
 *
 * Only one gate is consulted per ad (not a delegate list). Pass nil to clear the
 * current gate. When no gate is registered, ad loading is a zero-overhead
 * passthrough (no allocation, no dispatch).
 *
 * The gate's @c evaluateAd:completion: may be invoked on any thread; core
 * enforces a per-request timeout (default 3.0s) and fails open on expiry. See
 * the @c CLXAdQualityGate protocol for the full threading and lifecycle contract.
 *
 * @param gate The gate to register, or nil to clear. Thread-safe.
 * @discussion Safe to call before SDK initialization (e.g. from a module's
 * @c +load). Inert until a gate is registered.
 */
+ (void)setAdQualityGate:(nullable id<CLXAdQualityGate>)gate
    NS_SWIFT_NAME(setAdQualityGate(_:));

/**
 * The currently-registered ad-quality gate, or nil when none is set. Thread-safe.
 * @return The registered gate, or nil.
 */
+ (nullable id<CLXAdQualityGate>)adQualityGate;

@end

NS_ASSUME_NONNULL_END
