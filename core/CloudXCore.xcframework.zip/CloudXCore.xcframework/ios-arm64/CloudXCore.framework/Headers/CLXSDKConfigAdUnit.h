//
// CLXSDKConfigAdUnit.h
// CloudXCore
//

#import <Foundation/Foundation.h>
#import <CloudXCore/CLXNativeTemplate.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, SDKConfigAdType) {
    SDKConfigAdTypeBanner = 0,
    SDKConfigAdTypeMrec,
    SDKConfigAdTypeInterstitial,
    SDKConfigAdTypeRewarded,
    SDKConfigAdTypeNative,
    SDKConfigAdTypeAppOpen,
    SDKConfigAdTypeUnknown
};

@interface CLXSDKConfigAdUnit : NSObject

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) int64_t bidResponseTimeoutMs;
@property (nonatomic, readonly) NSTimeInterval bidRequestTimeoutSeconds;  // Derived from bidResponseTimeoutMs
@property (nonatomic, assign) int64_t adLoadTimeoutMs;
@property (nonatomic, assign) int64_t bannerRefreshRateMs;
@property (nonatomic, assign) BOOL bannerAutoRefreshDisabled;
@property (nonatomic, assign) SDKConfigAdType type;
@property (nonatomic, assign) BOOL hasCloseButton;
@property (nonatomic, assign) BOOL arbiterEnabled;
@property (nonatomic, assign) BOOL postBidEnabled;
@property (nonatomic, copy, nullable) NSString *firstImpressionPlacementSuffix;
@property (nonatomic, assign) NSInteger firstImpressionLoopIndexStart;
@property (nonatomic, assign) NSInteger firstImpressionLoopIndexEnd;
@property (nonatomic, assign) CLXNativeTemplate nativeTemplate;
@property (nonatomic, copy, nullable) NSString *dealId;
@property (nonatomic, copy, nullable) NSArray<id> *line_items;

// Rewarded ad configuration
@property (nonatomic, assign) NSInteger rewardAmount;
@property (nonatomic, copy, nullable) NSString *rewardCurrency;

// Warm-ad-cache (destroy-keeps-fill) per-ad-unit knobs (CXD-3096). Default OFF:
// `adCacheEnabled` is NO so an unconfigured ad unit keeps today's destroy
// behavior. Fill life comes from bid.exp, else the SDK's bid default; `cacheTtlMs`
// is ignored. When `adCacheEnabled` is YES, a destroyed ad object
// holding an unshown, unexpired fill deposits its fill bundle into the ad unit's
// `CLXAdUnitCoordinator` instead of tearing it down; the next `load()` for the
// same ad-unit ID adopts it synchronously. `preloadEnabled` and
// `maxConcurrentLoads` are parsed and stored now; consumed in later phases.
@property (nonatomic, assign) BOOL adCacheEnabled;
@property (nonatomic, assign) int64_t cacheTtlMs;
@property (nonatomic, assign) BOOL preloadEnabled;
@property (nonatomic, assign) NSInteger maxConcurrentLoads;

- (instancetype)init;
- (NSString *)ilrdDescription;

@end

NS_ASSUME_NONNULL_END
