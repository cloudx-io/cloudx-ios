#import <Foundation/Foundation.h>
#import <CloudXCore/CLXExport.h>
#import <CloudXCore/CLXNativeTemplate.h>
#import <CloudXCore/CLXSDKConfigRequest.h>
#import <CloudXCore/CLXSDKConfigBidder.h>
#import <CloudXCore/CLXSDKConfigAdUnit.h>

NS_ASSUME_NONNULL_BEGIN

// Forward declarations for classes defined in separate headers
@class CLXSDKConfigRequest;
@class CLXMetricsConfig;
@class CLXSDKConfigBidder;
@class CLXSDKConfigAdUnit;

// Forward declarations for classes defined in this file
@class CLXSDKConfigResponse;
@class CLXSDKConfigImp;
@class CLXSDKConfigBanner;
@class CLXSDKConfigFormat;
@class CLXSDKConfigSeatBid;
@class CLXSDKConfigBid;
@class CLXSDKConfigBidExt;
@class CLXSDKConfigCloudXExt;
@class CLXSDKConfigMeta;
@class CLXSDKConfigLineItem;
@class CLXSDKConfigQuantumValue;
@class CLXSDKConfigTargetingStrategy;
@class CLXSDKConfigTargeting;
@class CLXSDKConfigCondition;
@class CLXTelemetryMetricsConfig;
@class CLXTelemetryEventsConfig;
@class CLXTelemetryLogsConfig;
@class CLXRemoteLogConfig;
@class CLXSDKRaceSafetyConfig;
@class CLXSDKConfigDeviceConfig;
@class CLXSDKAdCacheConfig;

@interface CLXSDKConfig : NSObject

@property (nonatomic, copy, nullable) NSString *appKey;
@property (nonatomic, assign) BOOL isDebug;
@property (nonatomic, copy, nullable) NSString *accountID;
@property (nonatomic, copy, nullable) NSArray<CLXSDKConfigBidder *> *bidders;
@property (nonatomic, copy, nullable) NSArray<CLXSDKConfigAdUnit *> *adUnits;
@property (nonatomic, copy, nullable) NSString *auctionEndpointURL;
@property (nonatomic, copy, nullable) NSString *impressionTrackerURL;
@property (nonatomic, strong, nullable) CLXMetricsConfig *metricsConfig;
@property (nonatomic, strong, nullable) NSArray<NSString *> *tracking;

- (instancetype)init;
- (instancetype)initWithAppKey:(NSString *)appKey isDebug:(BOOL)isDebug;

@end

@interface CLXSDKConfigImp : NSObject
@property (nonatomic, copy) NSString *id;
@property (nonatomic, strong, nullable) CLXSDKConfigBanner *banner;
- (instancetype)init;
@end

@interface CLXSDKConfigBanner : NSObject
@property (nonatomic, strong) NSArray<CLXSDKConfigFormat *> *format;
- (instancetype)init;
@end

@interface CLXSDKConfigFormat : NSObject
@property (nonatomic, assign) NSInteger w;
@property (nonatomic, assign) NSInteger h;
- (instancetype)initWithWidth:(NSInteger)width height:(NSInteger)height;
@end

// Response structure
CLX_INTERNAL_TESTING
@interface CLXSDKConfigResponse : NSObject

@property (nonatomic, copy) NSString *accountID;
@property (nonatomic, copy) NSString *accountName;
@property (nonatomic, copy) NSString *organizationID;
@property (nonatomic, copy) NSString *appID;
/// Server-resolved country code. Empty string when unresolved.
@property (nonatomic, copy) NSString *country;

/// Server-issued opaque token; echoed verbatim on subsequent requests.
@property (nonatomic, copy) NSString *configPayload;

// 2. Endpoints (required)
@property (nonatomic, copy) NSString *auctionEndpointURL;
@property (nonatomic, copy) NSString *impressionTrackerURL;
@property (nonatomic, copy, nullable) NSString *arbiterEndpointURL;
@property (nonatomic, assign) NSInteger arbiterTimeoutMs;

// 2b. Event Telemetry Endpoints (optional — nil means telemetry for that event is disabled)
@property (nonatomic, copy, nullable) NSString *sdkInitEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkBidReqEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkLoadSuccessEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkLossEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkImpressionEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkClickEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkRewardEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkErrorEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkMetricsEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkLogEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkAdRevenueEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkCrashEndpointURL;
@property (nonatomic, assign) BOOL iosMetricKitCrashReportingEnabled;
@property (nonatomic, copy, nullable) NSString *sdkGamAuctionResultEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkOrchestrationStartEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkMediatorAttemptEndpointURL;
@property (nonatomic, copy, nullable) NSString *sdkOrchestratorSelectionEndpointURL;

// 2b-v. Server kill switches for speculative bid-token work. Both default to NO, so a
// payload that says nothing leaves the SDK collecting every token live under the asking
// request's own bound — the behaviour from before the token store existed, and the safe
// side of the rollout.
//
// `tokenPrefetchEnabled` gates every speculative background ask: the prefetch triggered as
// an adapter's init starts, and the ask fired when an after-init adapter reports ready.
// Neither is on a request's critical path, so switching them off costs latency, never fills.
//
// `tokenRefillEnabled` gates the refill that repopulates spent store slots after a bid
// request has been sent. Off means a taken token is simply gone until the next request
// collects one live.
//
// Off does NOT change which bidders gate init — that stays derived from token strategy
// alone, so an on-init-start bidder still holds the init gate and its token is collected
// live by the requests that need it.
@property (nonatomic, assign) BOOL tokenPrefetchEnabled;
@property (nonatomic, assign) BOOL tokenRefillEnabled;

// Applies background-refresh configs and auction config envelopes in session. Defaults to NO.
@property (nonatomic, assign) BOOL inSessionConfigApplyEnabled;

/*
 * Reward-callback timing. YES tells an adapter that holds the network's earned reward until its
 * own close callback to forward it at the grant instead, so an ad the user never closes still
 * pays. Reaches the adapter through localExtras; an adapter that already forwards at the grant is
 * unaffected. Defaults to NO, which is the timing that shipped before this switch existed.
 *
 * COLD, unlike every other behavioral switch here: it is pinned to the generation that
 * initialized the session, so one session is one A/B arm and a readout cannot straddle both
 * timings. The cost is no in-session kill switch -- turning it off takes effect at the next cold
 * start -- which is accepted for a flag rolled out per app through an experiment.
 */
@property (nonatomic, assign) BOOL rewardOnGrantEnabled;

// CXD-1176: adapter-lifecycle observability events flow through the metrics
// pipeline (single `sdkMetricsEndpointURL` + server-side allow-list in
// `telemetryMetricsConfig.metrics`). No per-event URLs needed.

// 2b-ii. Telemetry subsystem configs (server-driven tuning knobs)
@property (nonatomic, strong, nullable) CLXTelemetryMetricsConfig *telemetryMetricsConfig;
@property (nonatomic, strong, nullable) CLXTelemetryEventsConfig *telemetryEventsConfig;
@property (nonatomic, strong, nullable) CLXTelemetryLogsConfig *telemetryLogsConfig;

// 2b-iii. Server-driven remote log collection gates (nil when the server omits `remoteLogConfig`
// or sets `enabled=false`). When non-nil, applies level, substring filter, max-entries, and
// duration gates in the remote log tracker.
@property (nonatomic, strong, nullable) CLXRemoteLogConfig *remoteLogConfig;

// 2b-iv. Server-driven adapter lifecycle race-safety knobs (CXD-1182). Nil means all fixes
// remain off and the SDK keeps its legacy synchronous destroy + immediate VC-assignment
// behavior. See CLXSDKRaceSafetyConfig for per-field semantics.
@property (nonatomic, strong, nullable) CLXSDKRaceSafetyConfig *raceSafetyConfig;

// 2b-v. Server-driven warm-ad-cache global kill-switch envelope (CXD-3096).
// Nil when the server omits `adCacheConfig` so the SDK keeps its default
// (enabled = NO = today's byte-identical destroy behavior). When present,
// `enabled` gates the destroy-keeps-fill feature globally; each ad unit still
// opts in via `CLXSDKConfigAdUnit.adCacheEnabled`.
@property (nonatomic, strong, nullable) CLXSDKAdCacheConfig *adCacheConfig;

// 3. Core Config (required)
@property (nonatomic, strong) NSArray<CLXSDKConfigBidder *> *bidders;
@property (nonatomic, strong) NSArray<CLXSDKConfigAdUnit *> *adUnits;

// 4. Tracking (required)
@property (nonatomic, strong) NSArray<NSString *> *tracking;

// 5. Optional Config
@property (nonatomic, strong, nullable) CLXMetricsConfig *metricsConfig;
@property (nonatomic, strong, nullable) CLXSDKConfigDeviceConfig *deviceConfig;

/// SDK init network call latency in milliseconds (for metrics tracking)
@property (nonatomic, assign) NSInteger sdkInitLatencyMs;

/** Server timestamp in epoch millis from init response serverTimeMs field (for trusted clock sync). 0 if unavailable. */
@property (nonatomic, assign) long long serverTimestampMillis;

@property (nonatomic, copy, nullable) NSString *rawJSON;

- (instancetype)init;
@end

@interface CLXSDKConfigSeatBid : NSObject
@property (nonatomic, strong) NSArray<CLXSDKConfigBid *> *bid;
@property (nonatomic, copy) NSString *seat;
- (instancetype)init;
@end

@interface CLXSDKConfigBid : NSObject
@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *impid;
@property (nonatomic, assign) double price;
@property (nonatomic, copy) NSString *adm;
@property (nonatomic, copy) NSString *adid;
@property (nonatomic, strong) NSArray<NSString *> *adomain;
@property (nonatomic, copy) NSString *crid;
@property (nonatomic, assign) NSInteger w;
@property (nonatomic, assign) NSInteger h;
@property (nonatomic, strong, nullable) CLXSDKConfigBidExt *ext;
- (instancetype)init;
@end

@interface CLXSDKConfigBidExt : NSObject
@property (nonatomic, assign) double origbidcpm;
@property (nonatomic, copy, nullable) NSString *origbidcur;
@property (nonatomic, strong, nullable) CLXSDKConfigCloudXExt *cloudx;
- (instancetype)init;
@end

@interface CLXSDKConfigCloudXExt : NSObject
@property (nonatomic, strong, nullable) CLXSDKConfigMeta *meta;
@property (nonatomic, assign) NSInteger rank;
- (instancetype)init;
@end

@interface CLXSDKConfigMeta : NSObject
@property (nonatomic, copy) NSString *adaptercode;
- (instancetype)init;
@end

@interface CLXSDKConfigLineItem : NSObject
@property (nonatomic, copy, nullable) NSString *suffix;
@property (nonatomic, strong, nullable) CLXSDKConfigQuantumValue *targeting;
- (instancetype)init;
@end

@interface CLXSDKConfigQuantumValue : NSObject
@property (nonatomic, strong, nullable) CLXSDKConfigTargetingStrategy *targetingStrategy;
@property (nonatomic, strong, nullable) CLXSDKConfigTargeting *targeting;
- (instancetype)init;
- (nullable id)value;
@end

@interface CLXSDKConfigTargetingStrategy : NSObject
@property (nonatomic, copy) NSString *strategy;
- (instancetype)init;
@end

@interface CLXSDKConfigTargeting : NSObject
@property (nonatomic, copy) NSString *strategy;
@property (nonatomic, assign) BOOL conditionsAnd;
@property (nonatomic, copy) NSArray<CLXSDKConfigCondition *> *conditions;
- (instancetype)init;
@end

@interface CLXSDKConfigCondition : NSObject
@property (nonatomic, copy, nullable) NSArray<NSArray<NSDictionary<NSString *, CLXSDKConfigQuantumValue *> *> *> *whitelist;
@property (nonatomic, copy, nullable) NSArray<NSArray<NSDictionary<NSString *, CLXSDKConfigQuantumValue *> *> *> *blacklist;
@property (nonatomic, assign) BOOL conditionsAnd;
- (instancetype)init;
@end

/**
 * Device configuration from server init response
 * Controls test mode and debug logging on a per-device basis
 */
@interface CLXSDKConfigDeviceConfig : NSObject
/// Test mode value from server (0 = production, non-zero = test mode)
/// The value is passed through to bid requests as-is
@property (nonatomic, assign) NSInteger test;
/// Whether debug logging should be enabled for this device
@property (nonatomic, assign) BOOL debug;
@property (nonatomic, assign) BOOL optimisticLoadingEnabled;
/// Revert lever for the inline-video mute policy, not an opt-in feature: defaults
/// to YES so the policy stays active unless the server explicitly disables it.
@property (nonatomic, assign) BOOL inlineVideoMuteEnabled;
@property (nonatomic, assign) BOOL cachedInitEnabled;
/// App-wide fallback for the per-ad-unit concurrent publisher-load cap (CXD-3101).
/// 0 means "fall through to the SDK default (2)"; a value > 0 is the cap. Each ad
/// unit's own `maxConcurrentLoads` (on CLXSDKConfigAdUnit) overrides this when > 0.
@property (nonatomic, assign) NSInteger maxConcurrentLoadsPerAdUnit;

/// Server-driven gate for OMID ad-session creation on inline (non-fullscreen)
/// VAST video. Defaults to NO (fail-closed): an absent/null/malformed value and
/// any server that does not yet know about the flag both produce suppressed
/// inline OMID. Fullscreen VAST and display/HTML/MRAID OMID are unaffected by
/// this flag — it gates only the inline-video placement.
@property (nonatomic, assign) BOOL omidInlineVideoEnabled;
- (instancetype)init;
@end

NS_ASSUME_NONNULL_END
