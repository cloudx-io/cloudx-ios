/*
 * Copyright (c) 2024 CloudX. All rights reserved.
 */

/**
 * @file CLXUserDefaultsKeys.h
 * @brief Constants for User Defaults keys to prevent collisions
 * @details Centralized User Defaults key definitions with CLXCore_ prefix
 * to prevent collisions with other SDKs or host applications.
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * @brief Core SDK User Defaults keys with CLXCore_ prefix
 * @discussion These keys replace the previous unprefixed keys to prevent
 * collisions with other SDKs or host applications.
 */

// Core SDK session and configuration keys
#define kCLXCoreAppKeyKey @"CLXCore_appKey"
#define kCLXCoreSessionIDKey @"CLXCore_sessionIDKey"
#define kCLXCoreAccountIDKey @"CLXCore_accId_config"
#define kCLXCoreEncodedStringKey @"CLXCore_encodedString"
/// Persistent install UUID for source.ext.cx.install_id (generated once per app install)
#define kCLXCoreInstallIDKey @"CLXCore_installID"

// Metrics and analytics keys
#define kCLXCoreMetricsDictKey @"CLXCore_metricsDict"
#define kCLXCoreMetricsUrlKey @"CLXCore_metricsUrl"
#define kCLXCoreImpressionTrackerUrlKey @"CLXCore_impressionTrackerUrl"

// Additional configuration keys
#define kCLXCoreBundleConfigKey @"CLXCore_bundle_config"
#define kCLXCoreIFAConfigKey @"CLXCore_ifa_config"
#define kCLXCoreAIPromptKey @"CLXCore_aiPrompt"

// Banner-specific keys
#define kCLXCoreBannerAppKeyKey @"CLXCore_Banner_appKey"
#define kCLXCoreBannerSessionIDKey @"CLXCore_Banner_sessionIDKey"
#define kCLXCoreBannerMetricsDictKey @"CLXCore_Banner_metricsDict"
#define kCLXCoreBannerUserKeyValueKey @"CLXCore_Banner_userKeyValue"

// Debug/Development keys
#define kCLXCoreCloudXInitURLKey @"CLXCore_CloudXInitURL"

// Test and lifecycle keys
#define kCLXCoreCurrentStateKey @"CLXCore_currentState"
#define kCLXCoreCampaignIdKey @"CLXCore_campaignId"
#define kCLXCoreTestModeKey @"CLXCore_testMode"
#define kCLXCoreVisualDebuggingKey @"CLXCore_visualDebugging"

// Plugin/wrapper identification
#define kCLXCorePluginVersionKey @"CLXCore_pluginVersion"

// Banner-specific additional keys
#define kCLXBannerMetricsDictKey @"CLXBanner_metricsDict"
#define kCLXBannerUserKeyValueKey @"CLXBanner_userKeyValue"

// Network and tracking keys (UserDefaults keys only)
#define kCLXCoreDeviceKey @"CLXCore_device"
#define kCLXCoreDntKey @"CLXCore_dnt"
#define kCLXCoreUserAgentValueKey @"CLXCore_userAgent"

// Privacy service keys
// IAB standard keys for CMP compatibility (GDPR TCF, CCPA/US Privacy)
#define kCLXPrivacyGDPRConsentKey @"IABTCF_TCString"
#define kCLXPrivacyCCPAPrivacyKey @"IABUSPrivacy_String"
#define kCLXPrivacyGDPRAppliesKey @"IABTCF_gdprApplies"
#define kCLXPrivacyHashedGeoIpKey @"CLXPrivacyHashedGeoIp"


NS_ASSUME_NONNULL_END
