//
//  CLXVungleRewardedFactory.h
//  CloudXVungleAdapter
//

#import <Foundation/Foundation.h>

#if __has_include(<CloudXCore/CloudXCore.h>)
#import <CloudXCore/CloudXCore.h>
#else
@import CloudXCore;
#endif

NS_ASSUME_NONNULL_BEGIN

/**
 * Factory for creating Vungle rewarded adapters.
 * Implements the CloudX adapter factory protocol for rewarded ads.
 */
@interface CLXVungleRewardedFactory : NSObject <CLXAdapterRewardedFactory>

/**
 * Factory method to create a new factory instance
 * @return New factory instance
 */
+ (instancetype)createInstance;

@end

NS_ASSUME_NONNULL_END
