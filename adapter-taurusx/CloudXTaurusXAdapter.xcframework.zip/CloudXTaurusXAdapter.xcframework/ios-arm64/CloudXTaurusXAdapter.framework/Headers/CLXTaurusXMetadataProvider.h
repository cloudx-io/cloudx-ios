#import <Foundation/Foundation.h>
#import <CloudXCore/CLXAdapterMetadataProvider.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLXTaurusXMetadataProvider : CLXAdapterMetadataProvider
@end

NS_ASSUME_NONNULL_END
